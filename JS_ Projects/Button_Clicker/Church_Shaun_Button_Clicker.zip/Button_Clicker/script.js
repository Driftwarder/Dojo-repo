function navLoginLogout(element) {
    element.innerText = "Logout";
}

function hideDojonaryButton(element) {
element.remove()
}